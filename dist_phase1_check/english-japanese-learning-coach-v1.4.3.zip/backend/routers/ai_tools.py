"""Study plan, writing analysis, TTS, audio files, and chat WebSocket."""
from pathlib import Path

from api_errors import COMMON_ERROR_RESPONSES, api_error
from chat_handler import chat_manager
from config import settings
from database import db
from fastapi import APIRouter, Depends, WebSocket
from fastapi.responses import FileResponse
from models import (
    LanguageCode,
    StudyPlanGenerateRequest,
    StudyPlanResponse,
    TtsGenerateRequest,
    TtsResponse,
    WritingAnalysisResponse,
    WritingSubmission,
)
from study_planner import study_planner
from tts_service import tts_service
from writing_assistant import writing_assistant

from routers.deps import require_demo_user_id

router = APIRouter(prefix="/api", tags=["ai-tools"], responses=COMMON_ERROR_RESPONSES)

# WebSocket path is /ws/... (not under /api); separate router with no prefix.
chat_ws_router = APIRouter(tags=["ai-tools"])


@router.post("/study-plan/generate", response_model=StudyPlanResponse)
async def generate_study_plan(
    request: StudyPlanGenerateRequest,
    user_id: str = Depends(require_demo_user_id),
):
    progress = db.get_progress(user_id)
    current_progress = (
        progress["english_progress"]
        if request.language == "EN"
        else progress["japanese_progress"]
    )
    plan = await study_planner.generate_plan(
        user_id,
        request.target_goal,
        request.language,
        current_progress,
    )
    db.record_learning_activity(user_id=user_id, activity_type="study_plan_generate")
    return {"success": True, "plan": plan.model_dump(mode="json")}


@router.post("/writing/analyze", response_model=WritingAnalysisResponse)
async def analyze_writing(submission: WritingSubmission, user_id: str = Depends(require_demo_user_id)):
    analysis = await writing_assistant.analyze_writing(submission, user_id)
    db.record_learning_activity(user_id=user_id, activity_type="writing_analyze")
    return {"success": True, "analysis": analysis.model_dump(mode="json")}


@router.post("/tts", response_model=TtsResponse)
async def generate_tts(request: TtsGenerateRequest, user_id: str = Depends(require_demo_user_id)):
    audio_path = await tts_service.generate_audio(request.text, request.language)
    if not audio_path:
        return {
            "success": True,
            "available": False,
            "audio_url": None,
            "mode": "preview",
            "message": "TTS is integration-ready but no runtime provider is configured.",
        }
    return {"success": True, "available": True, "audio_url": f"/api/audio/{audio_path.name}", "mode": "live"}


@router.get("/audio/{filename}")
async def get_audio_file(filename: str):
    safe_name = Path(filename).name
    if not safe_name:
        raise api_error(400, "Invalid filename", "invalid_audio_filename")
    base = settings.audio_dir.resolve()
    file_path = (base / safe_name).resolve()
    try:
        file_path.relative_to(base)
    except ValueError:
        raise api_error(403, "Invalid audio path", "invalid_audio_path") from None
    if not file_path.exists():
        raise api_error(404, "Audio file not found", "audio_file_not_found")
    return FileResponse(file_path)


@chat_ws_router.websocket("/ws/chat/{language}")
async def websocket_endpoint(websocket: WebSocket, language: LanguageCode, scenario: str = "Daily Conversation"):
    await chat_manager.connect(websocket)
    await chat_manager.handle_chat(websocket, language, scenario)
