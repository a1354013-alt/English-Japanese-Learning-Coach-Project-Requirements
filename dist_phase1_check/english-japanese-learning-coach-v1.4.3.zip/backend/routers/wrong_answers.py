"""Wrong Answer Notebook CRUD + retry API."""

from api_errors import COMMON_ERROR_RESPONSES, api_error
from database import db
from fastapi import APIRouter, Depends, Query
from models import (
    SuccessResponse,
    WrongAnswer,
    WrongAnswerCreate,
    WrongAnswerItemResponse,
    WrongAnswerListResponse,
    WrongAnswerRetryRequest,
    WrongAnswerRetryResponse,
    WrongAnswerStatus,
    WrongAnswerUpdate,
)

from routers.deps import require_demo_user_id

router = APIRouter(prefix="/api", tags=["wrong-answers"], responses=COMMON_ERROR_RESPONSES)


@router.get("/wrong-answers", response_model=WrongAnswerListResponse)
async def list_wrong_answers(
    user_id: str = Depends(require_demo_user_id),
    status: WrongAnswerStatus | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
):
    items = db.list_wrong_answers(user_id=user_id, status=status, limit=limit, offset=offset)
    total = db.count_wrong_answers(user_id=user_id, status=status)
    return {"success": True, "count": total, "items": [WrongAnswer(**item).model_dump(mode="json") for item in items]}


@router.post("/wrong-answers", response_model=WrongAnswerItemResponse)
async def create_wrong_answer(
    payload: WrongAnswerCreate,
    user_id: str = Depends(require_demo_user_id),
):
    item = db.upsert_wrong_answer(
        user_id=user_id,
        language=payload.language,
        question_type=payload.question_type,
        question=payload.question,
        user_answer=payload.user_answer,
        correct_answer=payload.correct_answer,
        source_lesson_id=payload.source_lesson_id,
    )
    return {"success": True, "item": WrongAnswer(**item).model_dump(mode="json")}


@router.patch("/wrong-answers/{wrong_answer_id}", response_model=WrongAnswerItemResponse)
async def update_wrong_answer(
    wrong_answer_id: int,
    payload: WrongAnswerUpdate,
    user_id: str = Depends(require_demo_user_id),
):
    item = db.update_wrong_answer_status(user_id=user_id, wrong_answer_id=wrong_answer_id, status=payload.status)
    if not item:
        raise api_error(404, "Wrong answer not found", "wrong_answer_not_found")
    return {"success": True, "item": WrongAnswer(**item).model_dump(mode="json")}


@router.delete("/wrong-answers/{wrong_answer_id}", response_model=SuccessResponse)
async def delete_wrong_answer(
    wrong_answer_id: int,
    user_id: str = Depends(require_demo_user_id),
):
    ok = db.delete_wrong_answer(user_id=user_id, wrong_answer_id=wrong_answer_id)
    if not ok:
        raise api_error(404, "Wrong answer not found", "wrong_answer_not_found")
    return {"success": True}


@router.post("/wrong-answers/{wrong_answer_id}/retry", response_model=WrongAnswerRetryResponse)
async def retry_wrong_answer(
    wrong_answer_id: int,
    payload: WrongAnswerRetryRequest,
    user_id: str = Depends(require_demo_user_id),
):
    db.record_learning_activity(user_id=user_id, activity_type="retry_wrong_answer")
    correct, item = db.retry_wrong_answer(user_id=user_id, wrong_answer_id=wrong_answer_id, user_answer=payload.user_answer)
    if not item:
        raise api_error(404, "Wrong answer not found", "wrong_answer_not_found")
    return {"success": True, "correct": correct, "item": WrongAnswer(**item).model_dump(mode="json")}
