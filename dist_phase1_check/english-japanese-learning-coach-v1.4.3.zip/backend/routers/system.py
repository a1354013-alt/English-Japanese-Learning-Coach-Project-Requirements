"""Root metadata, health checks, user progress, analytics, and demo reset."""

from __future__ import annotations

from typing import Any, Dict, List

from api_errors import COMMON_ERROR_RESPONSES, api_error
from config import settings
from database import db
from demo_seed import reset_demo_dataset
from fastapi import APIRouter, Depends
from models import (
    AnalyticsResponse,
    DemoResetResponse,
    HealthCheckResponse,
    ProgressResponse,
    ReadyCheckResponse,
    RootResponse,
)
from ollama_client import ollama_client
from rag_manager import rag_manager
from services.streak_service import get_streak_snapshot
from time_utils import local_now
from version import get_app_version

from routers.deps import require_demo_user_id

APP_VERSION = get_app_version()

root_router = APIRouter(tags=["system"], responses=COMMON_ERROR_RESPONSES)
api_router = APIRouter(prefix="/api", tags=["system"], responses=COMMON_ERROR_RESPONSES)


@root_router.get("/", response_model=RootResponse)
async def root():
    return {
        "status": "healthy",
        "service": "Language Coach API",
        "version": APP_VERSION,
        "timestamp": local_now().isoformat(),
    }


@api_router.get("/health", response_model=HealthCheckResponse)
async def health_check():
    db_reachable = db.check_connection()
    return {
        "api": "healthy",
        "database": {
            "configured": bool(settings.db_path),
            "reachable": db_reachable,
            "ready": db_reachable,
        },
        "timestamp": local_now().isoformat(),
    }


@api_router.get("/ready", response_model=ReadyCheckResponse)
async def readiness_check():
    db_reachable = db.check_connection()
    ollama_small_ready = await ollama_client.check_model_availability(settings.small_model_name)
    ollama_large_ready = await ollama_client.check_model_availability(settings.large_model_name)
    return {
        "api": "healthy",
        "database": {
            "configured": bool(settings.db_path),
            "reachable": db_reachable,
            "ready": db_reachable,
        },
        "ollama": {
            "configured": bool(settings.ollama_url),
            "small_model": settings.small_model_name,
            "large_model": settings.large_model_name,
            "small_model_ready": ollama_small_ready,
            "large_model_ready": ollama_large_ready,
            "ready": ollama_small_ready or ollama_large_ready,
        },
        "rag": {
            "configured": settings.enable_rag,
            "ready": rag_manager.enabled,
            "error": rag_manager.init_error,
        },
        "timestamp": local_now().isoformat(),
    }


@api_router.post("/demo/reset", response_model=DemoResetResponse)
async def demo_reset(user_id: str = Depends(require_demo_user_id)):
    if not settings.allow_demo_reset:
        raise api_error(
            403,
            "Demo reset is disabled. Set ALLOW_DEMO_RESET=true only for local demo environments.",
            "demo_reset_disabled",
        )
    summary = reset_demo_dataset(db)
    return {"success": True, "message": "Demo dataset reset complete.", "summary": summary}


@api_router.get("/progress", response_model=ProgressResponse)
async def get_progress(user_id: str = Depends(require_demo_user_id)):
    streak = get_streak_snapshot(user_id)
    return {"success": True, "progress": db.get_progress(user_id), "streak": streak}


@api_router.get("/analytics", response_model=AnalyticsResponse)
async def get_analytics(user_id: str = Depends(require_demo_user_id)):
    streak_info = get_streak_snapshot(user_id)
    progress = db.get_progress(user_id)
    rpg_stats = progress.get("rpg_stats", {})
    english_completed = progress.get("english_progress", {}).get("completed_lessons", 0)
    japanese_completed = progress.get("japanese_progress", {}).get("completed_lessons", 0)
    total_lessons = english_completed + japanese_completed

    wrong_answers = db.list_wrong_answers(user_id=user_id, status="active", limit=500, offset=0)
    hardest_words = sorted(
        [{"word": item.get("question", "Unknown"), "mistakes": int(item.get("wrong_count", 1))} for item in wrong_answers],
        key=lambda item: item["mistakes"],
        reverse=True,
    )[:5]

    category_counts: Dict[str, int] = {}
    for item in wrong_answers:
        category = str(item.get("question_type") or "general")
        category_counts[category] = category_counts.get(category, 0) + 1

    weakest_category = None
    if category_counts:
        category, count = max(category_counts.items(), key=lambda item: item[1])
        weakest_category = {"category": category, "active_items": count}

    recent = db.list_recent_exercise_results(user_id=user_id, limit=5)
    accuracy_trend: List[Dict[str, Any]] = [
        {
            "lesson_id": result.get("lesson_id"),
            "latest_accuracy_rate": result.get("latest_accuracy_rate")
            if result.get("latest_accuracy_rate") is not None
            else result.get("accuracy_rate"),
            "best_accuracy_rate": result.get("accuracy_rate"),
            "submitted_at": result.get("submitted_at"),
        }
        for result in reversed(recent)
    ]
    mastery_state_counts = db.get_learning_item_stats(user_id=user_id)
    weakest_vocabulary = _analytics_learning_items(db.get_reviewed_learning_items(user_id=user_id, item_type="vocabulary"))
    weakest_grammar = _analytics_learning_items(db.get_reviewed_learning_items(user_id=user_id, item_type="grammar"))
    weakest_sentence_patterns = _analytics_learning_items(
        db.get_reviewed_learning_items(user_id=user_id, item_type="sentence_pattern")
    )
    recent_review_counts = db.get_recent_learning_item_review_counts(user_id=user_id)

    return {
        "success": True,
        "analytics": {
            "total_xp": rpg_stats.get("total_xp", 0),
            "level": rpg_stats.get("level", 1),
            "streak": streak_info["current_streak"],
            "longest_streak": streak_info["longest_streak"],
            "lessons_completed": total_lessons,
            "hardest_words": hardest_words,
            "weakest_category": weakest_category,
            "accuracy_trend": accuracy_trend,
            "today_completed": streak_info["today_completed"],
            "mastery_state_counts": mastery_state_counts,
            "weakest_vocabulary": weakest_vocabulary,
            "weakest_grammar": weakest_grammar,
            "weakest_sentence_patterns": weakest_sentence_patterns,
            "recent_7_day_review_counts": recent_review_counts,
        },
    }


def _analytics_learning_items(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [
        {
            "item_key": item.get("item_key"),
            "mastery_state": item.get("mastery_state"),
            "review_count": item.get("review_count", 0),
            "incorrect_count": item.get("incorrect_count", 0),
            "average_rating": item.get("average_rating", 0.0),
        }
        for item in items
    ]
