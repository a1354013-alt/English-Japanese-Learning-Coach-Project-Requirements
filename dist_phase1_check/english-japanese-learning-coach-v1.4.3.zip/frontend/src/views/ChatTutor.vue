<template>
  <section :class="['grid', 'view-page', { 'embedded-page': embedded }]">
    <div v-if="!embedded" class="panel row between center">
      <div>
        <h2 style="margin: 0">{{ t('chat.title') }}</h2>
        <p style="margin: 0.2rem 0 0; color: #475569; font-size: 0.9rem">
          {{ t('chat.subtitle') }}
        </p>
      </div>
      <select v-model="selectedLanguage" @change="reconnect">
        <option value="EN">{{ t('common.english') }}</option>
        <option value="JP">{{ t('common.japanese') }}</option>
      </select>
    </div>

    <div class="panel">
      <div class="chat-container">
        <div ref="messagesContainer" class="messages">
          <div v-if="connectionStatus === 'connecting'" class="system-message">
            {{ t('chat.connecting') }}
          </div>
          <div
            v-else-if="connectionStatus === 'reconnecting'"
            class="system-message"
          >
            {{ t('chat.reconnecting') }}
          </div>
          <div
            v-else-if="connectionStatus === 'error'"
            class="system-message error"
          >
            {{ t('chat.connectionFailed') }}
            <button
              class="secondary"
              style="margin-left: 0.5rem"
              @click="reconnect"
            >
              {{ t('chat.reconnect') }}
            </button>
          </div>

          <div
            v-for="(msg, idx) in messages"
            :key="idx"
            :class="['message', msg.role]"
          >
            <strong
              >{{
                msg.role === 'user' ? t('chat.you') : t('chat.tutor')
              }}:</strong
            >
            <span>{{ msg.text }}</span>
          </div>
        </div>

        <form class="chat-input-row" @submit.prevent="sendMessage">
          <input
            v-model="inputText"
            type="text"
            :placeholder="t('chat.messagePlaceholder')"
            :disabled="connectionStatus !== 'connected'"
            style="flex: 1; padding: 0.5rem"
          />
          <button
            type="submit"
            :disabled="!inputText.trim() || connectionStatus !== 'connected'"
          >
            {{ t('chat.send') }}
          </button>
        </form>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import type { Language } from '@/types'
import { resolveWebSocketBaseUrl } from '@/utils/wsUrl'

interface Message {
  role: 'user' | 'assistant' | 'system'
  text: string
}

type ConnectionStatus =
  | 'connecting'
  | 'connected'
  | 'reconnecting'
  | 'error'
  | 'disconnected'

const props = withDefaults(
  defineProps<{ embedded?: boolean; language?: Language }>(),
  {
    embedded: false,
    language: undefined,
  },
)

const { t } = useI18n()
const selectedLanguage = ref<Language>(props.language ?? 'EN')
const inputText = ref('')
const messages = ref<Message[]>([])
const connectionStatus = ref<ConnectionStatus>('disconnected')
const ws = ref<WebSocket | null>(null)
const messagesContainer = ref<HTMLElement | null>(null)
const reconnectAttempts = ref(0)
const connectionId = ref(0)
const maxReconnectAttempts = 5
const wsBaseUrl = resolveWebSocketBaseUrl({
  wsBaseUrl: import.meta.env.VITE_WS_BASE_URL,
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL,
  location: window.location,
})

const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

const languageLabel = () =>
  selectedLanguage.value === 'EN' ? t('common.english') : t('common.japanese')

const connect = () => {
  const activeConnectionId = connectionId.value + 1
  connectionId.value = activeConnectionId

  if (ws.value) {
    ws.value.close()
  }

  connectionStatus.value = 'connecting'
  const wsUrl = `${wsBaseUrl.replace(/\/$/, '')}/ws/chat/${selectedLanguage.value}`

  try {
    ws.value = new WebSocket(wsUrl)

    ws.value.onopen = () => {
      if (connectionId.value !== activeConnectionId) return
      connectionStatus.value = 'connected'
      reconnectAttempts.value = 0
      messages.value.push({
        role: 'system',
        text: t('chat.connectedToTutor', { language: languageLabel() }),
      })
    }

    ws.value.onmessage = (event) => {
      if (connectionId.value !== activeConnectionId) return
      try {
        const data = JSON.parse(event.data)
        if (data.text) {
          messages.value.push({
            role: data.role || 'assistant',
            text: data.text,
          })
          scrollToBottom()
        }
      } catch {
        messages.value.push({ role: 'system', text: t('chat.invalidMessage') })
      }
    }

    ws.value.onerror = () => {
      if (connectionId.value !== activeConnectionId) return
      connectionStatus.value = 'error'
    }

    ws.value.onclose = (event) => {
      if (connectionId.value !== activeConnectionId) return
      if (connectionStatus.value === 'error') {
        return
      }
      if (event.code === 1000 || event.code === 1001) {
        connectionStatus.value = 'disconnected'
        return
      }
      if (connectionStatus.value === 'connected') {
        handleReconnect()
      } else {
        connectionStatus.value = 'disconnected'
      }
    }
  } catch {
    connectionStatus.value = 'error'
  }
}

const handleReconnect = () => {
  if (reconnectAttempts.value >= maxReconnectAttempts) {
    connectionStatus.value = 'error'
    messages.value.push({
      role: 'system',
      text: t('chat.maxReconnectAttempts'),
    })
    return
  }

  connectionStatus.value = 'reconnecting'
  reconnectAttempts.value++

  const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.value), 5000)
  setTimeout(() => {
    if (connectionStatus.value === 'reconnecting') {
      connect()
    }
  }, delay)
}

const reconnect = () => {
  reconnectAttempts.value = 0
  connect()
}

const sendMessage = () => {
  const text = inputText.value.trim()
  if (!text || !ws.value || ws.value.readyState !== WebSocket.OPEN) return

  messages.value.push({ role: 'user', text })
  ws.value.send(JSON.stringify({ text }))
  inputText.value = ''
  scrollToBottom()
}

onMounted(() => {
  connect()
})

watch(
  () => props.language,
  (language) => {
    if (language && language !== selectedLanguage.value) {
      selectedLanguage.value = language
      reconnect()
    }
  },
)

onUnmounted(() => {
  connectionId.value++
  if (ws.value) {
    ws.value.close()
  }
})
</script>

<style scoped>
.chat-container {
  display: flex;
  flex-direction: column;
  height: 60vh;
}

.messages {
  flex: 1;
  overflow-y: auto;
  padding: 1rem;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  margin-bottom: 1rem;
  background: #f8fafc;
}

.message {
  margin-bottom: 0.75rem;
  padding: 0.5rem 0.75rem;
  border-radius: 6px;
  max-width: 80%;
}

.message.user {
  background: #dbeafe;
  margin-left: auto;
  text-align: right;
}

.message.assistant {
  background: #f1f5f9;
  margin-right: auto;
}

.message.system {
  background: #fef3c7;
  color: #92400e;
  font-style: italic;
  text-align: center;
  max-width: 100%;
}

.system-message {
  text-align: center;
  color: #64748b;
  font-style: italic;
  padding: 0.5rem;
}

.system-message.error {
  color: #b91c1c;
}

.chat-input-row {
  display: flex;
  gap: 0.5rem;
}

.chat-input-row button {
  min-width: 80px;
}

.chat-input-row button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.chat-input-row input:disabled {
  background: #f1f5f9;
  cursor: not-allowed;
}
</style>
