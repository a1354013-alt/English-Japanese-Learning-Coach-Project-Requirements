<template>
  <section class="grid" style="margin-top: 1rem">
    <div class="panel">
      <h2>{{ t('analytics.title') }}</h2>
      <p style="color: #64748b; margin-bottom: 1.5rem">
        {{ t('analytics.subtitle') }}
      </p>

      <LoadingState
        v-if="loading"
        panel-class="surface-muted"
        :message="t('analytics.loading')"
      />

      <ErrorState
        v-else-if="error"
        panel-class="error-panel"
        :message="error"
        :retry-label="t('common.retry')"
        @retry="loadAnalytics"
      />

      <div v-else-if="analytics" class="analytics-grid">
        <div class="stat-card">
          <h3>{{ t('analytics.totalXp') }}</h3>
          <p class="stat-value">{{ analytics.total_xp }}</p>
        </div>
        <div class="stat-card">
          <h3>{{ t('analytics.level') }}</h3>
          <p class="stat-value">{{ analytics.level }}</p>
        </div>
        <div class="stat-card">
          <h3>{{ t('analytics.currentStreak') }}</h3>
          <p class="stat-value">
            {{ t('analytics.days', { count: analytics.streak }) }}
          </p>
        </div>
        <div class="stat-card">
          <h3>{{ t('analytics.lessonsCompleted') }}</h3>
          <p class="stat-value">{{ analytics.lessons_completed }}</p>
        </div>

        <div class="panel-section">
          <h3>{{ t('analytics.hardestItems') }}</h3>
          <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 0.5rem">
            {{ t('analytics.hardestItemsHint') }}
          </p>
          <ul v-if="analytics.hardest_words.length > 0" class="word-list">
            <li
              v-for="(word, idx) in analytics.hardest_words"
              :key="idx"
              class="word-item"
            >
              <span class="word">{{ word.word }}</span>
              <span class="mistakes">{{
                t('analytics.mistakesCount', { count: word.mistakes })
              }}</span>
            </li>
          </ul>
          <p v-else style="color: #94a3b8">
            {{ t('analytics.noWrongAnswers') }}
          </p>
        </div>

        <div class="panel-section">
          <h3>{{ t('analytics.weakestCategory') }}</h3>
          <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 0.5rem">
            {{ t('analytics.weakestCategoryHint') }}
          </p>
          <div v-if="analytics.weakest_category" class="category-badge">
            {{ analytics.weakest_category.category }} ({{
              t('analytics.activeItems', {
                count: analytics.weakest_category.active_items,
              })
            }})
          </div>
          <p v-else style="color: #94a3b8">
            {{ t('analytics.notEnoughData') }}
          </p>
        </div>

        <div class="panel-section">
          <h3>{{ t('analytics.accuracyTrend') }}</h3>
          <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 0.5rem">
            {{ t('analytics.accuracyTrendHint') }}
          </p>
          <div v-if="analytics.accuracy_trend.length > 0" class="trend-grid">
            <div
              v-for="(p, idx) in analytics.accuracy_trend"
              :key="idx"
              class="trend-point"
            >
              <div class="trend-value">
                {{
                  t('analytics.latestAccuracyValue', {
                    rate: Number(p.latest_accuracy_rate).toFixed(1),
                  })
                }}
              </div>
              <div class="trend-meta">
                {{
                  t('analytics.bestAccuracyValue', {
                    rate: Number(p.best_accuracy_rate).toFixed(1),
                  })
                }}
              </div>
              <div class="trend-meta">
                {{ new Date(p.submitted_at).toLocaleDateString() }}
              </div>
            </div>
          </div>
          <p v-else style="color: #94a3b8">
            {{ t('analytics.noReviewHistory') }}
          </p>
        </div>

        <div class="panel-section">
          <h3>{{ t('analytics.learningItemsTitle') }}</h3>
          <div class="item-analytics-grid">
            <div>
              <h4>{{ t('analytics.masteryStates') }}</h4>
              <ul class="word-list">
                <li
                  v-for="item in masteryRows"
                  :key="item.label"
                  class="word-item"
                >
                  <span class="word">{{ item.label }}</span>
                  <span>{{ item.count }}</span>
                </li>
              </ul>
            </div>
            <div>
              <h4>{{ t('analytics.weakestLearningItems') }}</h4>
              <ul v-if="weakestLearningItems.length" class="word-list">
                <li
                  v-for="item in weakestLearningItems"
                  :key="`${item.group}-${item.item_key}`"
                  class="word-item"
                >
                  <span class="word">{{ item.item_key }}</span>
                  <span class="mistakes">{{ item.group }}</span>
                </li>
              </ul>
              <p v-else style="color: #94a3b8">
                {{ t('analytics.notEnoughData') }}
              </p>
            </div>
          </div>
        </div>

        <div class="panel-section">
          <h3>{{ t('analytics.recentReviewActivity') }}</h3>
          <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 0.5rem">
            {{ t('analytics.recentReviewActivityHint') }}
          </p>
          <ul v-if="recentReviewActivity.length" class="word-list">
            <li
              v-for="point in recentReviewActivity"
              :key="point.date"
              class="word-item"
            >
              <span class="word">{{ point.date }}</span>
              <span>
                {{ t('analytics.reviewCount', { count: point.count }) }}
              </span>
            </li>
          </ul>
          <p v-else style="color: #94a3b8">
            {{ t('analytics.noLearningItemReviewHistory') }}
          </p>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import ErrorState from '@/components/state/ErrorState.vue'
import LoadingState from '@/components/state/LoadingState.vue'
import { analyticsApi } from '@/services/api'
import type { AnalyticsPayload } from '@/types'

const { t } = useI18n()
const loading = ref(true)
const error = ref<string | null>(null)
const analytics = ref<AnalyticsPayload | null>(null)

const masteryRows = computed(() => {
  const counts = analytics.value?.mastery_state_counts ?? {}
  return Object.entries(counts).flatMap(([type, states]) =>
    Object.entries(states ?? {}).map(([state, count]) => ({
      label: `${type}: ${state}`,
      count,
    })),
  )
})

const weakestLearningItems = computed(() => [
  ...(analytics.value?.weakest_vocabulary ?? []).map((item) => ({
    ...item,
    group: t('analytics.vocabularyGroup'),
  })),
  ...(analytics.value?.weakest_grammar ?? []).map((item) => ({
    ...item,
    group: t('analytics.grammarGroup'),
  })),
  ...(analytics.value?.weakest_sentence_patterns ?? []).map((item) => ({
    ...item,
    group: t('analytics.sentencePatternGroup'),
  })),
])

const recentReviewActivity = computed(
  () => analytics.value?.recent_7_day_review_counts ?? [],
)

const loadAnalytics = async () => {
  loading.value = true
  error.value = null
  try {
    const res = await analyticsApi.getAnalytics()
    analytics.value = res.analytics
  } catch (err) {
    console.error(err)
    error.value = t('analytics.loadError')
  } finally {
    loading.value = false
  }
}

onMounted(loadAnalytics)
</script>

<style scoped>
.analytics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.stat-card {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 1rem;
  text-align: center;
}

.stat-card h3 {
  font-size: 0.85rem;
  color: #64748b;
  margin: 0 0 0.5rem 0;
  text-transform: uppercase;
}

.stat-value {
  font-size: 2rem;
  font-weight: bold;
  color: #1e293b;
  margin: 0;
}

.panel-section {
  grid-column: span 2;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 1rem;
}

@media (max-width: 768px) {
  .panel-section {
    grid-column: span 1;
  }
}

.word-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.word-item {
  display: flex;
  justify-content: space-between;
  padding: 0.5rem 0;
  border-bottom: 1px solid #e2e8f0;
}

.word-item:last-child {
  border-bottom: none;
}

.word {
  font-weight: 500;
}

.mistakes {
  color: #ef4444;
  font-size: 0.85rem;
}

.category-badge {
  display: inline-block;
  background: #fef3c7;
  color: #92400e;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  font-weight: 500;
}

.trend-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 0.75rem;
}

.trend-point {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 0.75rem;
  background: white;
}

.trend-value {
  font-weight: 700;
  font-size: 1.25rem;
}

.trend-meta {
  margin-top: 0.25rem;
  color: #64748b;
  font-size: 0.85rem;
}

.item-analytics-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1rem;
}

.item-analytics-grid h4 {
  margin: 0 0 0.5rem;
}

.error-panel {
  text-align: center;
  padding: 2rem;
  color: #b91c1c;
}

@media (max-width: 768px) {
  .item-analytics-grid {
    grid-template-columns: 1fr;
  }
}
</style>
